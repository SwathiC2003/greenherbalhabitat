package com.example.greenherbalhabitat.models

data class Category(
    val title : String? = null,
    val image : Int
)
