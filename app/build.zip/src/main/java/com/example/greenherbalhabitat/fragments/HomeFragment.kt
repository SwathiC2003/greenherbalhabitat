package com.example.greenherbalhabitat.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.greenherbalhabitat.Constants
import com.example.greenherbalhabitat.R
import com.example.greenherbalhabitat.adapters.AdapterCategory
import com.example.greenherbalhabitat.databinding.FragmentHomeBinding
import com.example.greenherbalhabitat.models.Category


class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentHomeBinding.inflate(layoutInflater)
        setAllCategories()
        return binding.root

    }


    private fun setAllCategories() {
        val categoryList = ArrayList<Category>()

        for (i in 0 until Constants.allProductsCategoryIcons.size){
            categoryList.add(Category(
                Constants.allProductsCategory[i],
                Constants.allProductsCategoryIcons[i]))
        }


        binding.rvCategories.adapter=AdapterCategory(categoryList,::onCategoryIconClicked)


    }
    fun onCategoryIconClicked(category: Category){
        val bundle=Bundle()
        bundle.putString("category",category.title)
        findNavController().navigate(R.id.action_homeFragment_to_categoryFragment,bundle)
    }



}