package com.example.greenherbalhabitat.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.example.greenherbalhabitat.CartListener
import com.example.greenherbalhabitat.R
import com.example.greenherbalhabitat.databinding.ActivityUsersMainBinding
import com.example.greenherbalhabitat.viewmodels.UserViewModel

class UsersMainActivity : AppCompatActivity() , CartListener {
    private lateinit var binding: ActivityUsersMainBinding
    private val viewModel : UserViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityUsersMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_users_main)
        setContentView(binding.root)
        getTotalItemCountIntCart()
    }

    private fun getTotalItemCountIntCart() {
        viewModel.fetchTotalCartItemCount().observe(this) {
            if (it > 0) {
                binding.llCart.visibility = View.VISIBLE
                binding.tvNumberOfProductCount.text=it.toString()
            }
            else{
                binding.llCart.visibility = View.GONE
            }
        }
    }

    override fun showCartLayout(itemCount:Int) {
        val previousCount =binding.tvNumberOfProductCount.text.toString().toInt()
        val updatedCount=previousCount + itemCount

        if (updatedCount>0){
            binding.llCart.visibility=View.VISIBLE
            binding.tvNumberOfProductCount.text=updatedCount.toString()

        }
        else{
            binding.llCart.visibility=View.GONE
            binding.tvNumberOfProductCount.text="0"
        }
    }

    override fun savingCartItemCount(itemCount: Int) {
        viewModel.fetchTotalCartItemCount().observe(this){
            viewModel.savingCartItemCount(it+itemCount)
        }


    }
}
