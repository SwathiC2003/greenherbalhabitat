package com.example.greenherbalhabitat

interface CartListener {

  fun showCartLayout(itemCount : Int)

  fun savingCartItemCount(itemCount : Int)


}